1. Run blackjackSever.bat
2. Enter Admin password which is "admin"
3. Choose Server settings (port number, number of player).
4. Click start server.
5. Run blackjackClient.bat
6. Enter port #, IP address of server( "localhost" if running on host computer), username and password and click on login
7. Enter the bet amount of chips. 
8. Wait for other players (if playing against multiple players).
